# Flutter App Project
Generated based on prompt: make an app which is use to store data as input send by user simple like todo app.

# Website Project

This project was generated based on the prompt: make a website like whatsapp. where user can communicate with other users.

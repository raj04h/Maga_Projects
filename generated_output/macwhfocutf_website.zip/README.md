# Website Project

This project was generated based on the prompt: make a calculator website having feature of scientific, currency exchanger, unit converter, trigometry function

# Website Project

This project was generated based on the prompt: create an simple website which showing message like "site under maintenance" . Service will soon start. Co-founder- Deepjoy Roy, Himanshu Raj. Product Designer- Yash tupkar, GenAI Engineer- Nitin kumar singh. write on the webpage.

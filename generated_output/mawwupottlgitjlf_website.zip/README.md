# Website Project

This project was generated based on the prompt: make a website where user place  order to the list given in the website. just like flipkart

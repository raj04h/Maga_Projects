# Android App Project
Generated based on prompt: make a drone maintence android app where having feature of scaning the image

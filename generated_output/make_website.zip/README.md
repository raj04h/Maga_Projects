# Make Website Project

This project was generated based on the prompt: make a calender website having feature to set date's message.

Okay, here's a basic Android calculator UI code in XML.  This is just the layout (the visual part).  I'll also give you some considerations for the logic (Java/Kotlin code) afterward.

**`activity_main.xml` (or equivalent layout file):**

```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:background="#F0F0F0"
    android:padding="16dp"
    tools:context=".MainActivity">

    <!-- Display (Input/Output) -->
    <TextView
        android:id="@+id/textViewResult"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginBottom="16dp"
        android:background="#FFFFFF"
        android:gravity="end|center_vertical"
        android:padding="8dp"
        android:textSize="36sp"
        android:singleLine="true"
        android:ellipsize="start"
        android:textColor="@android:color/black"
        android:hint="0"
        android:text="0" />

    <!-- Number and Operator Buttons -->
    <TableLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:stretchColumns="*">

        <!-- Row 1 -->
        <TableRow>
            <Button
                android:id="@+id/buttonClear"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="C"
                android:textSize="24sp"
                android:backgroundTint="#E0E0E0"
                android:textColor="@android:color/black"
                android:layout_margin="2dp"/>
            <Button
                android:id="@+id/buttonPlusMinus"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="+/-"
                android:textSize="24sp"
                android:backgroundTint="#E0E0E0"
                android:textColor="@android:color/black"
                android:layout_margin="2dp"/>
            <Button
                android:id="@+id/buttonPercent"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="%"
                android:textSize="24sp"
                android:backgroundTint="#E0E0E0"
                android:textColor="@android:color/black"
                android:layout_margin="2dp"/>
            <Button
                android:id="@+id/buttonDivide"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="/"
                android:textSize="24sp"
                android:backgroundTint="#FFAB40"
                android:textColor="@android:color/white"
                android:layout_margin="2dp"/>
        </TableRow>

        <!-- Row 2 -->
        <TableRow>
            <Button
                android:id="@+id/button7"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="7"
                android:textSize="24sp"
                android:backgroundTint="#BDBDBD"
                android:textColor="@android:color/black"
                android:layout_margin="2dp"/>
            <Button
                android:id="@+id/button8"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="8"
                android:textSize="24sp"
                android:backgroundTint="#BDBDBD"
                android:textColor="@android:color/black"
                android:layout_margin="2dp"/>
            <Button
                android:id="@+id/button9"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="9"
                android:textSize="24sp"
                android:backgroundTint="#BDBDBD"
                android:textColor="@android:color/black"
                android:layout_margin="2dp"/>
            <Button
                android:id="@+id/buttonMultiply"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="*"
                android:textSize="24sp"
                android:backgroundTint="#FFAB40"
                android:textColor="@android:color/white"
                android:layout_margin="2dp"/>
        </TableRow>

        <!-- Row 3 -->
        <TableRow>
            <Button
                android:id="@+id/button4"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="4"
                android:textSize="24sp"
                android:backgroundTint="#BDBDBD"
                android:textColor="@android:color/black"
                android:layout_margin="2dp"/>
            <Button
                android:id="@+id/button5"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="5"
                android:textSize="24sp"
                android:backgroundTint="#BDBDBD"
                android:textColor="@android:color/black"
                android:layout_margin="2dp"/>
            <Button
                android:id="@+id/button6"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="6"
                android:textSize="24sp"
                android:backgroundTint="#BDBDBD"
                android:textColor="@android:color/black"
                android:layout_margin="2dp"/>
            <Button
                android:id="@+id/buttonSubtract"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="-"
                android:textSize="24sp"
                android:backgroundTint="#FFAB40"
                android:textColor="@android:color/white"
                android:layout_margin="2dp"/>
        </TableRow>

        <!-- Row 4 -->
        <TableRow>
            <Button
                android:id="@+id/button1"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="1"
                android:textSize="24sp"
                android:backgroundTint="#BDBDBD"
                android:textColor="@android:color/black"
                android:layout_margin="2dp"/>
            <Button
                android:id="@+id/button2"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="2"
                android:textSize="24sp"
                android:backgroundTint="#BDBDBD"
                android:textColor="@android:color/black"
                android:layout_margin="2dp"/>
            <Button
                android:id="@+id/button3"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="3"
                android:textSize="24sp"
                android:backgroundTint="#BDBDBD"
                android:textColor="@android:color/black"
                android:layout_margin="2dp"/>
            <Button
                android:id="@+id/buttonAdd"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="+"
                android:textSize="24sp"
                android:backgroundTint="#FFAB40"
                android:textColor="@android:color/white"
                android:layout_margin="2dp"/>
        </TableRow>

        <!-- Row 5 -->
        <TableRow>
            <Button
                android:id="@+id/button0"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="2"
                android:text="0"
                android:textSize="24sp"
                android:backgroundTint="#BDBDBD"
                android:textColor="@android:color/black"
                android:layout_margin="2dp"
                android:layout_span="2"/>
            <Button
                android:id="@+id/buttonDecimal"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="."
                android:textSize="24sp"
                android:backgroundTint="#BDBDBD"
                android:textColor="@android:color/black"
                android:layout_margin="2dp"/>
            <Button
                android:id="@+id/buttonEquals"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="="
                android:textSize="24sp"
                android:backgroundTint="#FFAB40"
                android:textColor="@android:color/white"
                android:layout_margin="2dp"/>
        </TableRow>

    </TableLayout>

</LinearLayout>
```

**Explanation:**

*   **`LinearLayout`:** The root layout, arranges elements vertically.
*   **`TextView` (textViewResult):** This is where the input and result will be displayed. `android:gravity="end|center_vertical"` aligns text to the right and vertically centered within the view. `singleLine="true"` and `ellipsize="start"` prevent the text from wrapping to the next line and truncate it at the beginning if it exceeds the view's width.
*   **`TableLayout`:** Arranges buttons in a grid.  `android:stretchColumns="*" ` makes all columns equally sized.
*   **`TableRow`:** Represents each row in the table.
*   **`Button`:** The calculator buttons.  Each button has:
    *   `android:id`: A unique ID to reference in your Java/Kotlin code.
    *   `android:layout_width` and `android:layout_height`: Sets the size of the button.
    *   `android:layout_weight`:  Used with `TableLayout` to distribute space proportionally.
    *   `android:text`:  The label displayed on the button.
    *   `android:textSize`: The size of the text.
    *   `android:backgroundTint`: Sets the background color of the button.
    *   `android:textColor`: Sets the color of the text.
    *   `android:layout_margin`: Adds spacing around each button.
    *   `android:layout_span`: Used for the "0" button to occupy two columns.
*   **Colors:**  I've used some basic colors like `#BDBDBD` (Grey), `#FFAB40` (Orange), and `#F0F0F0` (light gray). You can change these to your preferred colors.  Using color resources (defining colors in `res/values/colors.xml`) is better for maintainability.
*   **Padding:**  The `LinearLayout` has padding to give the buttons some space from the edges of the screen.

**Important Considerations for the Logic (Java/Kotlin Code):**

1.  **Event Handling:**  In your `MainActivity.java` or `MainActivity.kt` file, you'll need to:

    *   Get references to each `Button` and the `TextView` using `findViewById()`.
    *   Set `OnClickListener`s for each button.
    *   Inside the `onClick()` method of each `OnClickListener`, determine which button was pressed.
    *   Update the `TextView` accordingly.

2.  **Input Handling:**

    *   Keep track of the current input number.
    *   Handle multiple digits correctly (appending digits to the current number).
    *   Handle the decimal point (only one allowed per number).
    *   Limit the number of digits that can be entered.

3.  **Operator Handling:**

    *   Store the first operand (number).
    *   Store the selected operator (+, -, *, /).
    *   When the "=" button is pressed, perform the calculation.

4.  **Calculation:**

    *   Implement the arithmetic operations.
    *   Handle division by zero (display an error).
    *   Consider using `BigDecimal` for more precise calculations, especially when dealing with decimals, to avoid floating-point precision issues.

5.  **Error Handling:**

    *   Handle invalid input (e.g., two operators in a row).
    *   Handle overflow (the result is too large to display).

6.  **Clear (C) Button:**

    *   Reset the display to "0".
    *   Clear the stored operands and operator.

7.  **"+"/"-" Button:**
    *   Change the sign of the current number.

8.  **Percent (%) Button:**
    *   Divide the current number by 100

**Example (Conceptual Java Code - MainActivity.java):**

```java
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView textViewResult;
    private Button button1, button2, button3, buttonAdd, buttonEquals, buttonClear; // Add all your buttons here
    private String currentInput = "0";
    private Double operand1 = null;
    private String operator = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewResult = findViewById(R.id.textViewResult);
        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        buttonAdd = findViewById(R.id.buttonAdd);
        buttonEquals = findViewById(R.id.buttonEquals);
        buttonClear = findViewById(R.id.buttonClear);


        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appendNumber("1");
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appendNumber("2");
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appendNumber("3");
            }
        });

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setOperator("+");
            }
        });

        buttonEquals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateResult();
            }
        });

        buttonClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clear();
            }
        });

        // Add similar listeners for all other buttons
    }

    private void appendNumber(String number) {
        if (currentInput.equals("0")) {
            currentInput = number;
        } else {
            currentInput += number;
        }
        textViewResult.setText(currentInput);
    }

    private void setOperator(String newOperator) {
        if (operand1 == null) {
            try {
                operand1 = Double.parseDouble(currentInput);
            } catch (NumberFormatException e) {
                // Handle invalid input
                return;
            }
            currentInput = "0"; // Reset for next number
            operator = newOperator;
        } else {
            // Handle case where the user presses an operator after entering a number and another operator
        }
        textViewResult.setText(currentInput);
    }

    private void calculateResult() {
        if (operand1 != null && operator != null) {
            double operand2;
            try {
                operand2 = Double.parseDouble(currentInput);
            } catch (NumberFormatException e) {
                return;
            }
            double result = 0;
            switch (operator) {
                case "+":
                    result = operand1 + operand2;
                    break;
                case "-":
                    result = operand1 - operand2;
                    break;
                case "*":
                    result = operand1 * operand2;
                    break;
                case "/":
                    if (operand2 != 0) {
                        result = operand1 / operand2;
                    } else {
                        textViewResult.setText("Error"); // Division by zero
                        clear();
                        return;
                    }
                    break;
            }
            textViewResult.setText(String.valueOf(result));
            currentInput = String.valueOf(result); //Result will be a start for next operation
            operand1 = null;
            operator = null; // Reset operator and operand for next calculation

        }
    }

    private void clear() {
        currentInput = "0";
        operand1 = null;
        operator = null;
        textViewResult.setText(currentInput);
    }
}
```

**Key Improvements and Next Steps:**

*   **Complete `OnClickListener` Implementations:** You need to implement `OnClickListener`s for all the buttons (0-9, +, -, \*, /, ., = , C, +/- , %).  The example only shows a few.
*   **Kotlin:** Consider using Kotlin instead of Java. Kotlin is generally preferred for new Android development due to its conciseness and safety features.
*   **Resource Management:** Use string resources (in `res/values/strings.xml`) for all the text on the buttons (e.g., `"button_1"` for the label "1"). This makes your app easier to localize (translate to other languages).  Also put the colors in `res/values/colors.xml`.
*   **More Robust Input:** Handle cases where the user presses an operator after entering a number, or multiple operators in a row.
*   **Error Handling:** Implement proper error handling for invalid input and calculations (e.g., division by zero, overflow).
*   **Testing:**  Write unit tests to ensure the calculator logic is correct.
*   **Advanced Features:**  Consider adding features like:
    *   Memory functions (M+, M-, MR, MC)
    *   Scientific functions (sin, cos, tan, log, etc.)
    *   History of calculations

This comprehensive response gives you a solid starting point for creating an Android calculator app.  Good luck!

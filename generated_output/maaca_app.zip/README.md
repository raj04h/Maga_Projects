# App Project

This project was generated based on the prompt: make an android calculator app
